﻿using System;
using System.Collections.Generic;
using System.Diagnostics.Eventing.Reader;
using System.Linq;
using System.Security.Cryptography.X509Certificates;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace L10DA1443022LAB
{
    internal class Program
    {
        static void Main(string[] args)
        {
            int q = 0;
            do
            {

                Console.WriteLine("ingrese nombre de usuario");
                string us = (Console.ReadLine());
                Console.WriteLine("ingrese contrasenna");
                string con = Console.ReadLine();

                bool usa = login(us, con);

                if ( usa == true) 
                { 
                  Console.WriteLine("usuario y contrase;a correcto");
                    q++;
                }
                 else 
                {
                    q++;
                    Console.WriteLine("usuario y contrasenna incorrectos");
                    Console.WriteLine("numero de intenos utilizados" + q);
                    Console.WriteLine("el numero de intentos maximos es 3");

                
                }
            }
            while (q<3);



            Console.ReadKey();
        }
       static bool login(string usuario, string contrasenna)
        {

            do
            {
                if (usuario == "usuario1" && contrasenna == "asdasd")
                {
                    return true;

                }
                else
                    return false;

            }
            while (false);

        }

        

    }
}
