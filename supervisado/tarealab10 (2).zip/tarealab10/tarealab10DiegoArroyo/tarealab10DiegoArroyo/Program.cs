﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tarealab10DiegoArroyo

{
    internal class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("lab10");
            Console.WriteLine("ingrese el cateto A");
            double lampara;
            lampara = double.Parse(Console.ReadLine());

            Triaungulo obttriangulo = new Triaungulo(lampara);

        }
    }
    class Triaungulo
    {
        double catetoA, anguloA, cA, altura, largo ;
        public Triaungulo (double Bases,double AnguloA, double catetA, double Altura, double Largo)
        {
            catetoA = Bases;
            anguloA = AnguloA;
            cA = catetA;
            altura = Altura;
            largo = Largo;
        }
        

        private double obtenercatetoA()
        {
            double CatetoA = catetoA*1 ;
            return CatetoA;
        }
        private double obtenercatetoB()
        {
            double CatetoB = catetoA / Math.Tan(anguloA);
            return CatetoB;

        }
        private double obtenercatetoC()
        {
            double CatetoC= catetoA / Math.Sin(anguloA);
            return CatetoC;
        }
        private double obtenerangulopouestoA()
        {
            double AngulopA = anguloA;
            return AngulopA;
        }
        private double obtenerangulopuestob()
        {
            double AngulopB= 180-anguloA-90;
            return AngulopB;
        }
        private double obtenerarea()
        {
            double Area = (largo * altura);
            return Area;
        }
        public void Calculargeometria(ref double uncatetoA, ref double uncatetoB, ref double uncatetoC, ref double unangulopA, ref double unangulopB, ref double unarea)
        {
            uncatetoA = obtenercatetoA();
            uncatetoB = obtenercatetoB();
            uncatetoC = obtenercatetoC();
            unangulopA = obtenerangulopouestoA();
            unangulopB = obtenerangulopuestob();
            unarea = obtenerarea();
        }
    }
}
