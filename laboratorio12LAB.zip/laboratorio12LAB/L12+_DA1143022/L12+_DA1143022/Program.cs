﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L12__DA1143022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            double[,] variable = new double[4, 5];
            double[,] matriz1 = new double[4, 5];
            double[,] sum = new double[4, 5];
            double ac1 = 0;
            double cont1 = 0;
            double promedio;
            Random r = new Random();

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    variable[i, j] = r.Next(100);
                    ac1 = ac1 + variable[i, j];
                    cont1++;

                }
            }
            promedio = ac1 / cont1;
            Console.WriteLine("EJERCICIO1");
            Console.WriteLine(" suma de la primera matriz " + ac1);
            Console.WriteLine(" promedio de la matriz " + promedio);

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {

                    matriz1[i, j] = r.Next(100);


                }
            }

            //ejercicio dos
            Console.WriteLine("EJERCICIO2");

            for (int i = 0; i < 4; i++)
            {
                for (int j = 0; j < 5; j++)
                {
                    sum[i, j] = matriz1[i, j] + variable[i, j];
                    Console.WriteLine("fila  " + i + " columna " + j);
                }
            }
            Console.ReadKey();
        }
    }
}
