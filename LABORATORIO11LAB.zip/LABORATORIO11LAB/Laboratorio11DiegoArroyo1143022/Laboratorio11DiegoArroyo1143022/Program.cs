﻿using System;
using System.Collections.Generic;
using System.Collections.Specialized;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Laboratorio11DiegoArroyo1143022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            //primera seccion
            int n1 = 0;
            Console.WriteLine("ingrese el numero de estudiantes de la primera seccion:");
            n1 = int.Parse(Console.ReadLine());


            double[] sec1;
            sec1 = new double[n1];

            double contS1apro = 0;
            double consS1repro = 0;
            double contnotas1 = 0;
            double contnotas12 = 0;

            for (int i = 0; i < n1; i++)
            {
                Console.WriteLine("ingrese la nota del estudiante" + (i + 1));
                sec1[i] = double.Parse(Console.ReadLine());

                if (sec1[i] >= 60)
                {
                    contS1apro++;
                }
                else
                {

                    consS1repro++;
                }

                if (sec1[i] > 90)
                {
                    contnotas1++;

                }
                else
                {

                    if (sec1[i] < 75)
                    {

                        contnotas12++;
                    }
                }
            }

            //segunda seccion 
            int n2 = 0;
            Console.WriteLine("ingrese el numero de estudiantes de la segunda seccion :");
            n2 = int.Parse(Console.ReadLine());


            double[] sec2;
            sec2 = new double[n1];

            double contS2Aprob = 0;
            double constS2repro = 0;
            double contnotas2 = 0;
            double contnotas22 = 0;

            for (int i = 0; i < n2; i++)
            {
                Console.WriteLine("ingrese la nota del estudiante " + (i + 1));
                sec2[i] = double.Parse(Console.ReadLine());

                if (sec2[i] >= 65)
                {
                    contS2Aprob++;
                }
                else
                {
                    constS2repro++;
                }

                if (sec2[i] > 90)
                {
                    contnotas2++;

                }
                else
                {

                    if (sec2[i] < 75)
                    {

                        contnotas22++;
                    }

                }



            }


                //porcietno aprovado seccion 1
                double porcentajea1 = (contS1apro / n1) * 100;
                Console.WriteLine("el porciento de aprovados en la seccion 1 es " + porcentajea1 + " %");

                //porciento reprovados seccion 1
                double porcentajer1 = (consS1repro / n1) * 100;
                Console.WriteLine("el porciento de reprovados en la seccion 1 es " + porcentajer1 + " %");

                //porcietno aprovado seccion 2
                double porcentajea2 = (contS2Aprob / n2) * 100;
                Console.WriteLine("el porciento de aprovados en la seccion 2 es " + porcentajea2 + " %");

                //porciento reprovados seccion 2
                double porcentajer2 = (constS2repro / n2) * 100;
                Console.WriteLine("el porciento de reprovados en la seccion 2 es " + porcentajer2 + " %");


                //porciento de aprovados y reprobados total

                double porcentajeapt = ((contS1apro + contS2Aprob) / (n1 + n2)) * 100;
                Console.WriteLine("el porciento de las dos secciones aprovados es" + porcentajeapt + " %");

                double porcentajerept = ((contS2Aprob + constS2repro) / (n1 + n2)) * 100;
                Console.WriteLine("el porciento de las dos secciones reprovados es" + porcentajerept + " %");




                //promedio seccion 1
                double suma = 0;

                for (int i = 0; i < n1; i++)
                {
                    suma = suma + sec1[i];

                }

                double promedio = suma / n1;

                Console.WriteLine("el promedio de la seccion 1 es" + promedio);

                //promedio seccion 2

                double suma2 = 0;

                for (int i = 0; i < n1; i++)
                {
                    suma2 = suma2 + sec1[i];

                }

                double promedio2 = suma2 / n2;

                Console.WriteLine("el promedio de la seccion 2 es" + promedio2);

                //promedio de notas total

                double promediototal = ((suma + suma2) / (n1 + n2));
                Console.WriteLine("promedio total de las dos secciones " + promediototal);

            // cantidad de estudiantes que tengan un prpomedio mayor a 90

            double may90 = contnotas1 + contnotas2;
            Console.WriteLine("la cantidad de estudiantes que tienen una nota mayor a 90 es: " + may90);

            double men75 = contnotas12 + contnotas22;
            Console.WriteLine("la cantidad de estudiantes que tienen una nota menor a 75 es: " + men75);

                Console.ReadKey();
            }
        }
    }
