﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DiegoArroyo_MichaelRivas_fase2proeycto
{
    internal class Program
    {
        static void Main(string[] args)
        {
        menu:
            Console.Clear();
            Panel_Control panel_Control = new Panel_Control();
            Iluminacion iluminacion = new Iluminacion();
            Ventilacion ventilacion = new Ventilacion();
            Calefaccion calefaccion = new Calefaccion();

            //menú
            Console.WriteLine("Bienvenido al sistema de control de la casa inteligente");
            Console.WriteLine("Escoja la opción que desea realizar:");
            Console.WriteLine("1. iluminacion");
            Console.WriteLine("2. ventilacion");
            Console.WriteLine("3. calefaccion");
            Console.WriteLine("4. Panel de control");
            Console.WriteLine("5. Salir");
            string opcion = Console.ReadLine();

            do
            {
                switch (opcion)
                {
                    case "1":
                        iluminacion.ControlarIluminacion();
                        goto menu;
                    case "2":
                        ventilacion.LeerHumedad();
                        goto menu;
                    case "3":
                        calefaccion.LeerTemperatura();
                        goto menu;
                    case "4":
                        panel_Control.MostrarPanel();
                        goto menu;
                    case "5":
                        Console.WriteLine("Gracias por utilizar el sistema");
                        break;
                    default:
                        Console.WriteLine("Opción no válida");
                        break;
                }
            } while (opcion != "5");
            Console.ReadKey();

            //panel_Control.MostrarPanel();
        }
        public class Calefaccion
        {
            public void LeerTemperatura()
            {
            leer:
                Console.Clear();
                int temperatura;
                string cuarto;

                Console.WriteLine("*******************ESTATUS ACTUAL DE LAS HABITACIONES***************************");
                Console.WriteLine("Temperatura Sala: " + VariablesGlobales.temperaturaSala + "°C");
                Console.WriteLine("Temperatura Habitacion 1: " + VariablesGlobales.temperaturaHabitacion1 + "°C");
                Console.WriteLine("Temperatura Habitacion 2: " + VariablesGlobales.temperaturaHabitacion2 + "°C");
                Console.WriteLine("Temperatura Comedor: " + VariablesGlobales.temperaturaComedor + "°C");
                Console.WriteLine("");
                Console.WriteLine("");

                try
                {
                    Console.WriteLine("Introduzca el número de la habitación que desea verificar");
                    Console.WriteLine("1. Sala");
                    Console.WriteLine("2. Habitación 1");
                    Console.WriteLine("3. Habitación 2");
                    Console.WriteLine("4. Comedor");
                    cuarto = Console.ReadLine();
                    Console.WriteLine("Introduzca la temperatura");
                    temperatura = Convert.ToInt32(Console.ReadLine());
                    if (temperatura < 18)
                    {
                        Console.WriteLine("Subiendo temperatura a 22ºC");
                        GuardarTemperatura(cuarto, 22);
                        VariablesGlobales.calefaccionEncendida = true;
                        //return 22;
                    }
                    else if (temperatura > 22)
                    {
                        Console.WriteLine("El valor de la temperatura está arriba de lo recomendado \n Bajando la temperatura a 22ºC");
                        GuardarTemperatura(cuarto, 22);
                        VariablesGlobales.calefaccionEncendida = true;
                        //return 22;
                    }
                    else
                    {
                        Console.WriteLine("Temperatura ideal");
                        GuardarTemperatura(cuarto, temperatura);
                        if (VariablesGlobales.temperaturaComedor == 22 && VariablesGlobales.temperaturaHabitacion1 == 22 && VariablesGlobales.temperaturaHabitacion2 == 22 && VariablesGlobales.temperaturaSala == 22)
                        {
                            VariablesGlobales.calefaccionEncendida = false;
                        }
                        //return 22;
                    }
                    Console.WriteLine("Presione cualquier tecla para continuar");
                    Console.ReadKey();
                }
                catch (Exception)
                {
                    Console.WriteLine("Ocurrio un error al leer la temperatura o al identificar la habitación, introdúzcala nuevamente");
                    goto leer;
                    throw;
                }
            }

            void GuardarTemperatura(string cuarto, int temperatura)
            {
                {
                    switch (cuarto)
                    {
                        case "1":
                            VariablesGlobales.temperaturaSala = temperatura;
                            break;
                        case "2":
                            VariablesGlobales.temperaturaHabitacion1 = temperatura;
                            break;
                        case "3":
                            VariablesGlobales.temperaturaHabitacion2 = temperatura;
                            break;
                        case "4":
                            VariablesGlobales.temperaturaComedor = temperatura;
                            break;
                        default:
                            break;
                    }
                }
            }
        }
        public class Iluminacion
        {
            public void ControlarIluminacion()
            {
            leer:
                Console.Clear();
                int cantidad_personas;
                string cuarto;
                string nombreCuarto;
                try
                {
                    Console.Clear();
                    //se imprime estatus actual de luces en habitación
                    Console.WriteLine("*******************ESTATUS ACTUAL DE LAS HABITACIONES***************************");
                    Console.WriteLine("Sala: " + VariablesGlobales.lucesSala);
                    Console.WriteLine("Habitacion 1: " + VariablesGlobales.lucesHabitacion1);
                    Console.WriteLine("Habitacion 2: " + VariablesGlobales.lucesHabitacion2);
                    Console.WriteLine("Comedor: " + VariablesGlobales.lucesComedor);
                    Console.WriteLine("");
                    Console.WriteLine("");
                    Console.WriteLine("Introduzca el número de la habitación que desea modificar");
                    Console.WriteLine("1. Sala");
                    Console.WriteLine("2. Habitación 1");
                    Console.WriteLine("3. Habitación 2");
                    Console.WriteLine("4. Comedor");
                    cuarto = Console.ReadLine();
                    Console.WriteLine("Introduzca la cantidad de personas en la habitación");
                    cantidad_personas = Convert.ToInt32(Console.ReadLine());
                }
                catch (Exception)
                {
                    Console.WriteLine("Ocurrio un error al leer la cantidad de personas o al identificar la habitación, introdúzcala nuevamente");
                    Console.WriteLine("Presione cualquier tecla para continuar");
                    Console.ReadKey();
                    goto leer;
                    throw;
                }

                if (cantidad_personas > 0)
                {
                    //lectura de habitación si hay más de 1 persona
                    switch (cuarto)
                    {
                        case "1":
                            VariablesGlobales.lucesSala = "Encendidas";
                            VariablesGlobales.iluminacionEncendida = true;
                            nombreCuarto = "Sala";
                            break;
                        case "2":
                            VariablesGlobales.lucesHabitacion1 = "Encendidas";
                            VariablesGlobales.iluminacionEncendida = true;
                            nombreCuarto = "Habitación 1";
                            break;
                        case "3":
                            VariablesGlobales.lucesHabitacion2 = "Encendidas";
                            VariablesGlobales.iluminacionEncendida = true;
                            nombreCuarto = "Habitación 2";
                            break;
                        case "4":
                            VariablesGlobales.lucesComedor = "Encendidas";
                            VariablesGlobales.iluminacionEncendida = true;
                            nombreCuarto = "Comedor";
                            break;
                        default:
                            Console.WriteLine("Ocurrio un error al identificar la habitación, introdúzcala nuevamente");
                            Console.ReadKey();
                            goto leer;
                    }
                    string mensaje = "Encendiendo iluminación en: " + nombreCuarto + " con " + cantidad_personas + " personas";
                    Console.WriteLine(mensaje);

                }
                else
                {
                    //se lee la habitación en caso estén apagadas
                    switch (cuarto)
                    {
                        case "1":
                            VariablesGlobales.lucesSala = "Apagadas";
                            nombreCuarto = "Sala";
                            break;
                        case "2":
                            VariablesGlobales.lucesHabitacion1 = "Apagadas";
                            nombreCuarto = "Habitación 1";
                            break;
                        case "3":
                            VariablesGlobales.lucesHabitacion2 = "Apagadas";
                            nombreCuarto = "Habitación 2";
                            break;
                        case "4":
                            VariablesGlobales.lucesComedor = "Apagadas";
                            nombreCuarto = "Comedor";
                            break;
                        default:
                            Console.WriteLine("Ocurrio un error al identificar la habitación, introdúzcala nuevamente");
                            Console.ReadKey();
                            goto leer;
                    }
                    // Si todas las luces están apagadas significa que el sistema de iluminación está apagado
                    if (VariablesGlobales.lucesSala == "Apagadas" && VariablesGlobales.lucesHabitacion1 == "Apagadas" && VariablesGlobales.lucesHabitacion2 == "Apagadas" && VariablesGlobales.lucesComedor == "Apagadas")
                    {
                        VariablesGlobales.iluminacionEncendida = false;
                    }
                    string mensaje = "Apagando iluminación en: " + nombreCuarto + " con 0 personas";
                    Console.WriteLine(mensaje);

                }
                Console.ReadKey();

            }



        }
        public class Panel_Control
        {
            public void MostrarPanel()
            {

            leerHora:
                //se limpia la pantalla previa antes de mostrarla
                Console.Clear();
                //se lee la hora para ver si ya se necesitan comenzar los procesos programados
                HoraProgramada();

                //Calcular promedio de temperaturas
                VariablesGlobales.temperatura = PromedioTemp();
                VariablesGlobales.humedad = PromedioHum();
                //se muestra el panel de control
                Console.WriteLine(@"                                        ");
                Console.WriteLine(@"              WX0OOOOOO0XW              ");
                Console.WriteLine(@"              NkooooooookN              ");
                Console.WriteLine(@"      WNW    WKxooooooooxKW    WNW      ");
                Console.WriteLine(@"     NOxxO0K0kdoooooooooodk0K0OxxON     ");
                Console.WriteLine(@"    NkooooooooooooooooooooooooooookN                    Hora de activación: " + VariablesGlobales.horaIncio_sistemas.ToString("HH:mm:ss"));
                Console.WriteLine(@"   XkoooooooooooodxkkxdooooooooooookX                   Fecha: " + VariablesGlobales.fecha);
                Console.WriteLine(@"  WXxooooooooodOKNWWWWNKOdoooooooooxXW                  Temperatura promedio: " + VariablesGlobales.temperatura + "°C");
                Console.WriteLine(@"    NKkdooooodKW        WKdooooodkKN                    Humedad promedio: " + VariablesGlobales.humedad + "%");
                Console.WriteLine(@"      XxoooooOW          WOoooooxX      ");
                Console.WriteLine(@"     WKxoooookN          NkoooooxKW     ");
                Console.WriteLine(@"   NKkdoooooookXW      WXkooooooodkKN   ");
                Console.WriteLine(@"  WKdoooooooooodk0KKKK0kdoooooooooodKW  ");
                Console.WriteLine(@"   W0dooooooooooooooooooooooooooood0W   ");
                Console.WriteLine(@"    WKxoodxkxdoooooooooooodxkxdooxKW    ");
                Console.WriteLine(@"      X0KXNWWXOdoooooooodOXWWNXK0X      ");
                Console.WriteLine(@"              XxooooooooxX              ");
                Console.WriteLine(@"              W0dddddddd0W              ");
                Console.WriteLine(@"               WNNNNNNNNW               ");
                //se pone el cursor al lado del engranaje
                Console.SetCursorPosition(56, 10);
                Console.WriteLine("Estatus de sistemas: ");

                //se validan si los sistemas están encendidos. Si lo están, se muestra un mensaje de que están encendidos

                if (VariablesGlobales.ventilacionEncendida)
                {
                    Console.SetCursorPosition(56, 11);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Ventilación ✓");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.SetCursorPosition(56, 11);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Ventilación X");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                if (VariablesGlobales.iluminacionEncendida)
                {
                    Console.SetCursorPosition(56, 12);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Iluminación ✓");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.SetCursorPosition(56, 12);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Iluminación X");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                if (VariablesGlobales.calefaccionEncendida)
                {
                    Console.SetCursorPosition(56, 13);
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.WriteLine("Calefacción ✓");
                    Console.ForegroundColor = ConsoleColor.White;
                }
                else
                {
                    Console.SetCursorPosition(56, 13);
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("Calefacción X");
                    Console.ForegroundColor = ConsoleColor.White;
                }

                Console.SetCursorPosition(56, 14);
                Console.WriteLine("1. Programar sistemas");
                Console.SetCursorPosition(56, 15);
                Console.WriteLine("2. Regresar al menú");
                Console.SetCursorPosition(56, 16);
                string opcion = Console.ReadLine();
                switch (opcion)
                {
                    case "1":
                        Console.SetCursorPosition(56, 17);
                        Console.WriteLine("Ingrese la hora del día para iniciar programa:");
                        Console.SetCursorPosition(56, 18);
                        Console.WriteLine("Formato 24 horas: HH:MM:SS");
                        Console.SetCursorPosition(56, 19);
                        break;
                    case "2":
                        goto salir;
                    default:
                        Console.SetCursorPosition(56, 17);
                        Console.WriteLine("Opción no válida");
                        Console.ReadKey();
                        goto leerHora;
                }


                string hora = "";

                try
                {
                    //se valida si la hora es válida o no
                    hora = Console.ReadLine();
                    VariablesGlobales.horaIncio_sistemas = Convert.ToDateTime(hora);
                    Console.SetCursorPosition(56, 20);
                    Console.Write("Hora ingresada correctamente");
                }
                catch (Exception)
                {
                    Console.SetCursorPosition(56, 21);
                    Console.WriteLine("Ocurrió un error al leer la hora, vuelve a ingresarla");
                    Console.ReadKey();
                    goto leerHora;
                }
            salir:
                Console.SetCursorPosition(56, 22);
                //se regresa al menú principal
                Console.WriteLine("Presione cualquier tecla para volver al menú inicial");
                Console.ReadKey();

            }
            string PromedioTemp()
            {
                //se calcula el promedio
                double promedio = (VariablesGlobales.temperaturaComedor + VariablesGlobales.temperaturaSala + VariablesGlobales.temperaturaHabitacion1 + VariablesGlobales.temperaturaHabitacion2) / 4;
                //se devuelve redondeado a dos unidades
                return Convert.ToString(Math.Round(promedio, 2));


            }
            string PromedioHum()
            {
                //se calcula el promedio
                double promedio = (VariablesGlobales.humedadComedor + VariablesGlobales.humedadSala + VariablesGlobales.humedadHabitacion1 + VariablesGlobales.humedadHabitacion2) / 4;
                //se devuelve redondeado a dos unidades
                return Convert.ToString(Math.Round(promedio, 2));


            }

            void HoraProgramada()
            {

                //se valida si la hora es igual a la hora programada
                if (VariablesGlobales.horaIncio_sistemas.Hour == DateTime.Now.Hour && VariablesGlobales.horaIncio_sistemas.Minute == DateTime.Now.Minute)
                {
                    //se encienden los sistemas
                    VariablesGlobales.ventilacionEncendida = true;
                    VariablesGlobales.iluminacionEncendida = true;
                    VariablesGlobales.calefaccionEncendida = true;
                    //se modifican las humedades a las normales
                    VariablesGlobales.humedadSala = 54;
                    VariablesGlobales.humedadComedor = 54;
                    VariablesGlobales.humedadHabitacion1 = 54;
                    VariablesGlobales.humedadHabitacion2 = 54;

                    //se modifican las temperaturas a las normales
                    VariablesGlobales.temperaturaSala = 22;
                    VariablesGlobales.temperaturaHabitacion1 = 22;
                    VariablesGlobales.temperaturaHabitacion2 = 22;
                    VariablesGlobales.temperaturaComedor = 22;
                    Console.WriteLine("Actualizando los sistemas automáticamente según la hora");
                }


            }
        }
        public static class VariablesGlobales
        {
            public static string hora = "00:00:00";
            public static DateTime horaIncio_sistemas;
            public static string fecha = DateTime.Now.ToString("dd/MM/yyyy");
            public static string temperatura = "00.00";
            public static string humedad = "00.00";
            public static int temperaturaHabitacion1 = 0;
            public static int temperaturaHabitacion2 = 0;
            public static int temperaturaSala = 0;
            public static int temperaturaComedor = 0;

            public static string lucesHabitacion1 = "Apagadas";
            public static string lucesHabitacion2 = "Apagadas";
            public static string lucesSala = "Apagadas";
            public static string lucesComedor = "Apagadas";

            public static int humedadHabitacion1 = 0;
            public static int humedadHabitacion2 = 0;
            public static int humedadSala = 0;
            public static int humedadComedor = 0;


            public static bool ventilacionEncendida = false;
            public static bool iluminacionEncendida = false;
            public static bool calefaccionEncendida = false;
        }
        public class Ventilacion
        {
            public void LeerHumedad()
            {

            leer:
                Console.Clear();
                string cuarto;

                //mostrando la humedad en habitaciones
                Console.WriteLine("*******************ESTATUS ACTUAL DE LAS HABITACIONES***************************");
                Console.WriteLine("Humedad Sala: " + VariablesGlobales.humedadSala + "%");
                Console.WriteLine("Humedad Habitacion 1: " + VariablesGlobales.humedadHabitacion1 + "%");
                Console.WriteLine("Humedad Habitacion 2: " + VariablesGlobales.humedadHabitacion2 + "%");
                Console.WriteLine("Humedad Comedor: " + VariablesGlobales.humedadComedor + "%");
                Console.WriteLine("");
                Console.WriteLine("");
                try
                {
                    //Leyendo las habitaciones
                    Console.WriteLine("Introduzca el número de la habitación que desea verificar");
                    Console.WriteLine("1. Sala");
                    Console.WriteLine("2. Habitación 1");
                    Console.WriteLine("3. Habitación 2");
                    Console.WriteLine("4. Comedor");
                    cuarto = Console.ReadLine();
                    Console.WriteLine("Introduzca la humedad");
                    int humedad = Convert.ToInt32(Console.ReadLine());
                    //si la humedad es menor a 70 pero mayor a 0
                    if (humedad <= 70 && humedad > 0)
                    {
                        //si la humedad es menor a 30 se debe encender los ventiladores
                        if (humedad < 30)
                        {
                            Console.WriteLine("La humedad del aire no es recomendable");
                            Console.WriteLine("Encendiendo ventilador");
                            humedad = 58;
                            switch (cuarto)
                            {
                                case "1":
                                    VariablesGlobales.humedadSala = humedad;
                                    VariablesGlobales.ventilacionEncendida = true;
                                    break;
                                case "2":
                                    VariablesGlobales.humedadHabitacion1 = humedad;
                                    VariablesGlobales.ventilacionEncendida = true;
                                    break;
                                case "3":
                                    VariablesGlobales.humedadHabitacion2 = humedad;
                                    VariablesGlobales.ventilacionEncendida = true;
                                    break;
                                case "4":
                                    VariablesGlobales.humedadComedor = humedad;
                                    VariablesGlobales.ventilacionEncendida = true;
                                    break;
                                default:
                                    Console.WriteLine("Habitación no valida");
                                    Console.WriteLine("Presione cualquier tecla para continuar");
                                    Console.ReadKey();
                                    goto leer;
                            }
                        }
                        //si la humedad es normal, se deja tal cual
                        else
                        {
                            Console.WriteLine("Humedad normal: " + humedad);
                            switch (cuarto)
                            {
                                case "1":
                                    VariablesGlobales.humedadSala = humedad;
                                    break;
                                case "2":
                                    VariablesGlobales.humedadHabitacion1 = humedad;
                                    break;
                                case "3":
                                    VariablesGlobales.humedadHabitacion2 = humedad;
                                    break;
                                case "4":
                                    VariablesGlobales.humedadComedor = humedad;
                                    break;
                                default:
                                    Console.WriteLine("Habitación no valida");
                                    Console.WriteLine("Presione cualquier tecla para continuar");
                                    Console.ReadKey();
                                    goto leer;
                            }
                            if (VariablesGlobales.ventilacionEncendida == true)
                            {
                                Console.WriteLine("Apagando ventilador");
                                VariablesGlobales.ventilacionEncendida = false;
                            }
                        }

                    }
                    //Encender ventiladores, humedad mayor a 70
                    else if (humedad > 70)
                    {
                        Console.WriteLine("Niveles de humedad muy altos");
                        Console.WriteLine("Encendiendo ventilador");
                        humedad = 58;
                        switch (cuarto)
                        {
                            case "1":
                                VariablesGlobales.humedadSala = humedad;
                                VariablesGlobales.ventilacionEncendida = true;
                                break;
                            case "2":
                                VariablesGlobales.humedadHabitacion1 = humedad;
                                VariablesGlobales.ventilacionEncendida = true;
                                break;
                            case "3":
                                VariablesGlobales.humedadHabitacion2 = humedad;
                                VariablesGlobales.ventilacionEncendida = true;
                                break;
                            case "4":
                                VariablesGlobales.humedadComedor = humedad;
                                VariablesGlobales.ventilacionEncendida = true;
                                break;
                            default:
                                Console.WriteLine("Habitación no valida");
                                Console.WriteLine("Presione cualquier tecla para continuar");
                                Console.ReadKey();
                                goto leer;
                        }
                    }
                    else
                    {
                        Console.WriteLine("Ocurrió un error al leer la humedad");
                        Console.WriteLine("Presione cualquier tecla para continuar");
                        Console.ReadKey();
                        goto leer;
                    }
                    Console.WriteLine("Presione cualquier tecla para continuar");
                    Console.ReadKey();
                }
                catch (Exception)
                {
                    Console.WriteLine("Ocurrió un error al leer la humedad");
                    goto leer;
                    throw;
                }

            }
        }
    }
}
