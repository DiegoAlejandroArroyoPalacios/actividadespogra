﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace tarea1lab
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            int n = int.Parse(textBox1.Text);
            int x = n;
            int res;
            string bin = string.Empty;

            while (n > 0)
            {
                res = n % 2;
                n /= 2;
                bin = res.ToString() + bin;
            }
            label1.Text = x + " es igual a " + bin;
        }
    }
}

