﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection.Emit;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace L8_DA_1143022
{
    public partial class Form1 : Form

    {
        public Form1()
        {
            InitializeComponent();

            comboBox1.Items.Add("sumatoria");
            comboBox1.Items.Add("tabla de multiplicar");
            comboBox1.Items.Add("numero perfecto");
         
            if (comboBox1.SelectedItem != null)
            {
                MessageBox.Show(comboBox1.SelectedItem.ToString());
            }
          

        }

        private void label1_Click(object sender, EventArgs e)
        {
            InitializeComponent();


        }

        private void button1_Click(object sender, EventArgs e)
        {
            int primernum = 0, resultado = 0;

            primernum = Convert.ToInt32(textBox1.Text);

            for (int i = 0; i <= primernum; i++)
            {
                resultado = resultado + i;
            }

            textBox2.Text = resultado.ToString();
        }
        private void combobox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        
        }

        private void tabPage3_Click(object sender, EventArgs e)
        {
        }

        private void label4_Click(object sender, EventArgs e)
        {
            string m = "";
            for (int i = 1; i <= 10; i++)
            {
                for (int j = 1; j <= 10; j++)
                {
                    if (j <= 9)
                    {
                        m = m + Convert.ToString(i * j) + "\t";
                    }
                    if (j == 10)
                    {
                        m = m + Convert.ToString(i * j) + "\n";
                    }
                }
                label4.Text = Convert.ToString(m);
            }
        }

        private void tabPage4_Click(object sender, EventArgs e)
        {
            int numE = int.Parse(textBox3.Text);
            int suma = 0;
            for (int i = 1; i < numE; i++)
            {
                if (numE % i == 0)
                {
                    suma = suma + i;
                }

            }


            if (suma == numE)
            {
                label5.Text = "El número es perfecto";
            }
            else
            {
                label5.Text = "El número no es perfecto";
            }
        }
    }
}
   
