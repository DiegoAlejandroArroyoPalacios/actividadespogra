﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace L1DA_1443022
{
    internal class Program
    {
        static void Main(string[] args)
        {
            // parte 1 practica laboratorio 
            Console.WriteLine("Hola Mundo Soy Diego ");
            string Nombre = Console.ReadLine();

            // writeline escribe en linea por linea con separacion

            Console.WriteLine("hola mundo");
            Console.WriteLine("soy " + Nombre);

            // write escribe en una sola linea sin separacion

            Console.Write("hola mundo");
            Console.Write("soy" + Nombre);


            //parte 2 laboratorio 

            Console.WriteLine("segunda parte tarea No1");

            Console.WriteLine("mi segundo programa");

            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("ingrese su nombre");
            string sNombre = Console.ReadLine();
            Console.WriteLine("");
            Console.WriteLine("ingrese su edad");
            string sEdad = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("ingrese su carrera");
            string sCarrera = Console.ReadLine();

            Console.WriteLine("");
            Console.WriteLine("ingrese su carnee");
            string sCarnee = Console.ReadLine();

            Console.WriteLine();

            Console.WriteLine("nombre:" + sNombre);
            Console.WriteLine("edad:" + sEdad);
            Console.WriteLine("carrera:" + sCarrera);
            Console.WriteLine("carnee:" + sCarnee);
            Console.WriteLine();
            Console.WriteLine();

            Console.WriteLine("soy" + sNombre + ",tengo" + sEdad + "Annos y estudio la carrera de" + sCarrera + ",Mi numero de carne es;" + sCarnee);

            Console.ReadKey();
        }
    }
}
